import { create } from 'zustand';
import { User, Message } from '../types';
import { socket } from '../lib/socket';

interface AppState {
  user: User | null;
  messages: Message[];
  isAudioEnabled: boolean;
  isVideoEnabled: boolean;
  connectionStatus: 'disconnected' | 'connecting' | 'connected';
  setUser: (user: User | null) => void;
  addMessage: (message: Message) => void;
  toggleAudio: () => void;
  toggleVideo: () => void;
  setConnectionStatus: (status: 'disconnected' | 'connecting' | 'connected') => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  messages: [],
  isAudioEnabled: true,
  isVideoEnabled: true,
  connectionStatus: 'disconnected',
  setUser: (user) => set({ user }),
  addMessage: (message) => set((state) => ({ messages: [...state.messages, message] })),
  toggleAudio: () => set((state) => {
    if (state.user) {
      socket.emit('toggle_audio', { userId: state.user.id });
      return { isAudioEnabled: !state.isAudioEnabled };
    }
    return state;
  }),
  toggleVideo: () => set((state) => {
    if (state.user) {
      socket.emit('toggle_video', { userId: state.user.id });
      return { isVideoEnabled: !state.isVideoEnabled };
    }
    return state;
  }),
  setConnectionStatus: (status) => set({ connectionStatus: status }),
}));