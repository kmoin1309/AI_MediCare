import React from 'react';
import { Mic, MicOff, Video, VideoOff, PhoneOff } from 'lucide-react';
import { useStore } from '../store/useStore';

interface VideoControlsProps {
  onEndCall: () => void;
}

export const VideoControls: React.FC<VideoControlsProps> = ({ onEndCall }) => {
  const { isAudioEnabled, isVideoEnabled, toggleAudio, toggleVideo } = useStore();

  return (
    <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex items-center gap-4 bg-gray-900/80 px-6 py-3 rounded-full">
      <button
        onClick={toggleAudio}
        className={`p-3 rounded-full ${
          isAudioEnabled ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-500 hover:bg-red-600'
        }`}
      >
        {isAudioEnabled ? (
          <Mic className="w-6 h-6 text-white" />
        ) : (
          <MicOff className="w-6 h-6 text-white" />
        )}
      </button>
      <button
        onClick={toggleVideo}
        className={`p-3 rounded-full ${
          isVideoEnabled ? 'bg-gray-700 hover:bg-gray-600' : 'bg-red-500 hover:bg-red-600'
        }`}
      >
        {isVideoEnabled ? (
          <Video className="w-6 h-6 text-white" />
        ) : (
          <VideoOff className="w-6 h-6 text-white" />
        )}
      </button>
      <button
        onClick={onEndCall}
        className="p-3 rounded-full bg-red-500 hover:bg-red-600"
      >
        <PhoneOff className="w-6 h-6 text-white" />
      </button>
    </div>
  );
};