export interface User {
  id: string;
  name: string;
  role: 'doctor' | 'patient';
}

export interface ConsultationRoom {
  id: string;
  doctorId: string;
  patientId: string;
  status: 'waiting' | 'active' | 'ended';
}

export interface Message {
  id: string;
  senderId: string;
  content: string;
  timestamp: number;
}