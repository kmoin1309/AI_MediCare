import React from 'react';
import { useStore } from '../store/useStore';

export const ConnectionStatus: React.FC = () => {
  const { connectionStatus } = useStore();

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'bg-green-500';
      case 'connecting':
        return 'bg-yellow-500';
      case 'disconnected':
        return 'bg-red-500';
    }
  };

  return (
    <div className="absolute top-4 left-4 flex items-center gap-2">
      <div className={`w-3 h-3 rounded-full ${getStatusColor()}`} />
      <span className="text-white text-sm font-medium">
        {connectionStatus.charAt(0).toUpperCase() + connectionStatus.slice(1)}
      </span>
    </div>
  );
};