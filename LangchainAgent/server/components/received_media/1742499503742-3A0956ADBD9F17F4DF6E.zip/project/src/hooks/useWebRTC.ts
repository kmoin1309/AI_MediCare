import { useEffect, useRef, useState } from 'react';
import { useStore } from '../store/useStore';
import { socket } from '../lib/socket';

const configuration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

export const useWebRTC = (roomId: string) => {
  const peerConnection = useRef<RTCPeerConnection | null>(null);
  const localStream = useRef<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const { user, setConnectionStatus, isAudioEnabled, isVideoEnabled } = useStore();
  const [error, setError] = useState<string | null>(null);

  const setupMediaStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      localStream.current = stream;
      stream.getAudioTracks()[0].enabled = isAudioEnabled;
      stream.getVideoTracks()[0].enabled = isVideoEnabled;
      return stream;
    } catch (err) {
      setError('Failed to access camera and microphone');
      throw err;
    }
  };

  const createPeerConnection = () => {
    const pc = new RTCPeerConnection(configuration);
    
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        socket.emit('ice_candidate', { roomId, candidate: event.candidate });
      }
    };

    pc.ontrack = (event) => {
      setRemoteStream(event.streams[0]);
    };

    pc.onconnectionstatechange = () => {
      switch (pc.connectionState) {
        case 'connected':
          setConnectionStatus('connected');
          break;
        case 'disconnected':
        case 'failed':
          setConnectionStatus('disconnected');
          setRemoteStream(null);
          break;
        case 'connecting':
          setConnectionStatus('connecting');
          break;
      }
    };

    return pc;
  };

  const initializeCall = async () => {
    try {
      const stream = await setupMediaStream();
      const pc = createPeerConnection();
      peerConnection.current = pc;
      
      stream.getTracks().forEach(track => {
        if (pc && localStream.current) {
          pc.addTrack(track, localStream.current);
        }
      });

      return { localStream: stream, peerConnection: pc };
    } catch (err) {
      setError('Failed to initialize call');
      throw err;
    }
  };

  useEffect(() => {
    if (localStream.current) {
      const audioTrack = localStream.current.getAudioTracks()[0];
      const videoTrack = localStream.current.getVideoTracks()[0];
      if (audioTrack) audioTrack.enabled = isAudioEnabled;
      if (videoTrack) videoTrack.enabled = isVideoEnabled;
    }
  }, [isAudioEnabled, isVideoEnabled]);

  useEffect(() => {
    const setupCallHandlers = async () => {
      socket.on('start_call', async () => {
        try {
          const { peerConnection } = await initializeCall();
          
          if (user?.role === 'doctor') {
            const offer = await peerConnection.createOffer({
              offerToReceiveAudio: true,
              offerToReceiveVideo: true,
            });
            await peerConnection.setLocalDescription(offer);
            socket.emit('offer', { roomId, offer });
          }
        } catch (err) {
          setError('Failed to start call');
        }
      });

      socket.on('offer', async ({ offer }) => {
        try {
          const { peerConnection } = await initializeCall();
          await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
          
          const answer = await peerConnection.createAnswer();
          await peerConnection.setLocalDescription(answer);
          socket.emit('answer', { roomId, answer });
        } catch (err) {
          setError('Failed to process offer');
        }
      });

      socket.on('answer', async ({ answer }) => {
        try {
          if (peerConnection.current) {
            await peerConnection.current.setRemoteDescription(
              new RTCSessionDescription(answer)
            );
          }
        } catch (err) {
          setError('Failed to process answer');
        }
      });

      socket.on('ice_candidate', async ({ candidate }) => {
        try {
          if (peerConnection.current && peerConnection.current.remoteDescription) {
            await peerConnection.current.addIceCandidate(
              new RTCIceCandidate(candidate)
            );
          }
        } catch (err) {
          setError('Failed to add ICE candidate');
        }
      });

      socket.on('user_left', () => {
        setConnectionStatus('disconnected');
        setRemoteStream(null);
        if (peerConnection.current) {
          peerConnection.current.close();
        }
      });
    };

    setupCallHandlers();

    return () => {
      if (localStream.current) {
        localStream.current.getTracks().forEach(track => track.stop());
      }
      if (peerConnection.current) {
        peerConnection.current.close();
      }
      socket.off('start_call');
      socket.off('offer');
      socket.off('answer');
      socket.off('ice_candidate');
      socket.off('user_left');
      setRemoteStream(null);
    };
  }, [roomId, user]);

  return {
    localStream: localStream.current,
    remoteStream,
    error,
  };
};