import React, { useEffect, useRef } from 'react';
import { VideoControls } from '../components/VideoControls';
import { Chat } from '../components/Chat';
import { ConnectionStatus } from '../components/ConnectionStatus';
import { useNavigate, useParams } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { useWebRTC } from '../hooks/useWebRTC';
import { socket } from '../lib/socket';

export const DoctorView: React.FC = () => {
  const navigate = useNavigate();
  const { roomId = 'default-room' } = useParams();
  const { setConnectionStatus, user } = useStore();
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const { localStream, remoteStream, error } = useWebRTC(roomId);

  useEffect(() => {
    if (user) {
      socket.emit('join_room', { roomId, user });
    }
  }, [roomId, user]);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  const handleEndCall = () => {
    setConnectionStatus('disconnected');
    navigate('/');
  };

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="bg-red-500 text-white px-6 py-4 rounded-lg">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-900">
      <div className="flex-1 relative">
        <ConnectionStatus />
        <div className="grid grid-cols-2 gap-4 h-full p-4">
          <div className="relative bg-gray-800 rounded-lg overflow-hidden">
            <video
              ref={localVideoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
              muted
            />
            <div className="absolute bottom-4 left-4 bg-gray-900/60 px-3 py-1 rounded-lg">
              <span className="text-white text-sm">Dr. Smith (You)</span>
            </div>
          </div>
          <div className="relative bg-gray-800 rounded-lg overflow-hidden">
            <video
              ref={remoteVideoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
            />
            <div className="absolute bottom-4 left-4 bg-gray-900/60 px-3 py-1 rounded-lg">
              <span className="text-white text-sm">Patient</span>
            </div>
          </div>
        </div>
        <VideoControls onEndCall={handleEndCall} />
      </div>
      <div className="w-96 p-4">
        <Chat />
      </div>
    </div>
  );
};