import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"],
  },
});

const rooms = new Map();

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join_room", ({ roomId, user }) => {
    const room = rooms.get(roomId) || { users: [], messages: [] };

    if (room.users.length >= 2) {
      socket.emit("room_full");
      return;
    }

    if (room.users.some((u) => u.role === user.role)) {
      socket.emit("role_taken");
      return;
    }

    socket.join(roomId);
    room.users.push({ ...user, socketId: socket.id });
    rooms.set(roomId, room);

    // Send existing messages to the new user
    socket.emit("room_joined", {
      roomId,
      users: room.users,
      messages: room.messages,
    });
    socket.to(roomId).emit("user_joined", { user });

    if (room.users.length === 2) {
      io.to(roomId).emit("start_call");
    }
  });

  socket.on("ice_candidate", ({ roomId, candidate }) => {
    socket.to(roomId).emit("ice_candidate", { candidate });
  });

  socket.on("offer", ({ roomId, offer }) => {
    socket.to(roomId).emit("offer", { offer });
  });

  socket.on("answer", ({ roomId, answer }) => {
    socket.to(roomId).emit("answer", { answer });
  });

  socket.on("send_message", ({ roomId, message }) => {
    const room = rooms.get(roomId);
    if (room) {
      room.messages.push(message);
      // Broadcast the message to all users in the room
      io.to(roomId).emit("new_message", { message });
    }
  });

  socket.on("toggle_audio", ({ userId }) => {
    for (const [roomId, room] of rooms.entries()) {
      const user = room.users.find((u) => u.socketId === socket.id);
      if (user) {
        socket.to(roomId).emit("user_toggle_audio", { userId });
        break;
      }
    }
  });

  socket.on("toggle_video", ({ userId }) => {
    for (const [roomId, room] of rooms.entries()) {
      const user = room.users.find((u) => u.socketId === socket.id);
      if (user) {
        socket.to(roomId).emit("user_toggle_video", { userId });
        break;
      }
    }
  });

  socket.on("disconnect", () => {
    for (const [roomId, room] of rooms.entries()) {
      const userIndex = room.users.findIndex((u) => u.socketId === socket.id);
      if (userIndex !== -1) {
        room.users.splice(userIndex, 1);
        if (room.users.length === 0) {
          rooms.delete(roomId);
        } else {
          socket.to(roomId).emit("user_left", { socketId: socket.id });
        }
        break;
      }
    }
    console.log("User disconnected:", socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
